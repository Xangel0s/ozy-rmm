"use client"

import {
  Activity,
  Bell,
  ChevronsUpDown,
  LayoutDashboard,
  MonitorSmartphone,
  Settings,
  TerminalSquare,
} from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { tenants } from "@/lib/rmm-data"
import { cn } from "@/lib/utils"

const nav = [
  { label: "Dashboard", icon: LayoutDashboard, active: true, badge: null },
  { label: "Monitored Devices", icon: MonitorSmartphone, active: false, badge: "148" },
  { label: "Automation / Scripts", icon: TerminalSquare, active: false, badge: null },
  { label: "Alerts", icon: Bell, active: false, badge: "3" },
  { label: "Settings", icon: Settings, active: false, badge: null },
]

export function Sidebar({
  tenant,
  onTenantChange,
}: {
  tenant: string
  onTenantChange: (value: string) => void
}) {
  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar">
      <div className="flex h-14 items-center gap-2 border-b border-sidebar-border px-4">
        <div className="flex size-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Activity className="size-4" />
        </div>
        <div className="flex flex-col leading-none">
          <span className="text-sm font-semibold tracking-tight text-sidebar-foreground">
            ApexRMM
          </span>
          <span className="text-[11px] text-muted-foreground">Operations Console</span>
        </div>
      </div>

      <div className="border-b border-sidebar-border p-3">
        <label className="mb-1.5 block px-1 text-[11px] font-medium tracking-wide text-muted-foreground uppercase">
          Active Client
        </label>
        <Select value={tenant} onValueChange={onTenantChange}>
          <SelectTrigger className="w-full bg-secondary/60">
            <SelectValue>
              {(value: string) => tenants.find((t) => t.id === value)?.name}
            </SelectValue>
            <ChevronsUpDown className="ml-auto size-3.5 text-muted-foreground" />
          </SelectTrigger>
          <SelectContent>
            {tenants.map((t) => (
              <SelectItem key={t.id} value={t.id}>
                <span className="flex w-full items-center justify-between gap-3">
                  <span>{t.name}</span>
                  <span className="text-xs text-muted-foreground">{t.devices}</span>
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <nav className="flex-1 space-y-1 p-3">
        {nav.map((item) => (
          <a
            key={item.label}
            href="#"
            aria-current={item.active ? "page" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-md px-2.5 py-2 text-sm font-medium transition-colors",
              item.active
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
            )}
          >
            <item.icon className="size-4 shrink-0" />
            <span className="flex-1 truncate">{item.label}</span>
            {item.badge && (
              <span
                className={cn(
                  "rounded-full px-1.5 py-0.5 text-[10px] font-semibold",
                  item.label === "Alerts"
                    ? "bg-destructive/15 text-destructive"
                    : "bg-secondary text-muted-foreground",
                )}
              >
                {item.badge}
              </span>
            )}
          </a>
        ))}
      </nav>

      <div className="border-t border-sidebar-border p-3">
        <div className="flex items-center gap-3 rounded-md px-1 py-1">
          <div className="flex size-8 items-center justify-center rounded-full bg-secondary text-xs font-semibold text-foreground ring-1 ring-border">
            JM
          </div>
          <div className="flex min-w-0 flex-col leading-tight">
            <span className="truncate text-sm font-medium">Jordan Meyer</span>
            <span className="truncate text-xs text-muted-foreground">Systems Engineer</span>
          </div>
        </div>
      </div>
    </aside>
  )
}
